﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Clínica_Viva_Bem
{
    class Program
    {
        // GERADOR DE CODIGO CONSULTA
        public static int GerarCodigoC()
        {
            int codigo2 = 1;
            StreamReader ler = new StreamReader("Consultas.txt");
            string linha;

            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    codigo2++;
                }

            } while (linha != null);
            ler.Close();
            return codigo2;

        }
        // GERADOR DE CODIGO PACIENTE
        public static int GerarCodigoP2()
        {
            int codigo2 = 1;
            StreamReader ler = new StreamReader("CadastroPaciente.txt");
            string linha;

            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    codigo2++;
                }

            } while (linha != null);
            ler.Close();
            return codigo2;
        }
        // GERADOR DE CODIGO MEDICO
        public static int GerarCodigoM2()
        {
            int codigo2 = 1;
            StreamReader ler = new StreamReader("Cadastromedico.txt");
            string linha;

            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    codigo2++;
                }

            } while (linha != null);
            ler.Close();
            return codigo2;
        }

        // CADASTRAR PACIENTE
        public static void cadastrarpaciente()
        {
            int opcao;
            do
            {
                Console.Clear();
                Console.WriteLine("|| ---------------------------------\n|| CADASTRO DE PACIENTE \n|| --------------------------------- ");



                string nome, endereco, telefone, nascimento;
                int codigo;
                StreamWriter x;
                string CadastroPaciente = "CadastroPaciente.txt";

                //usando o metodo e abrindo o arquivo texto
                x = File.AppendText(CadastroPaciente);

                Console.WriteLine("|| ============================================");
                Console.WriteLine("|| INSIRA SEU NOME: ");
                Console.Write("|| ");
                nome = Console.ReadLine().ToUpper();
                Console.WriteLine("|| INSIRA SEU ENDEREÇO: (EX: RUA DAS MANGABEIRAS, 95, ELDORADO, CONTAGEM, MG) ");
                Console.Write("|| ");
                endereco = Console.ReadLine().ToUpper();
                Console.WriteLine("|| INSIRA SEU TELEFONE: ");
                Console.Write("|| ");
                telefone = Console.ReadLine();
                Console.WriteLine("|| INSIRA SUA DATA DE NASCIMENTO: (EX: 20/10/2000) ");
                Console.Write("|| ");
                nascimento = Console.ReadLine().ToUpper();
                x.Close();
                codigo = GerarCodigoP2();
                x = File.AppendText(CadastroPaciente);
                x.WriteLine(nome + "|" + endereco + "|" + telefone + "|" + nascimento + "|" + codigo);
                Console.WriteLine("Seu código é: " + codigo);
                x.Close();

                Console.Clear();
                Console.WriteLine("|| PACIENTE CADASTRADO COM SUCESSO!");
                Console.WriteLine("\n\n|| [1] CADASTRAR OUTRO PACIENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                Console.Write("||     ");
                opcao = int.Parse(Console.ReadLine());
                Console.Clear();
            } while (opcao != 0);
        }

        // CADASTRAR MEDICO
        public static void cadastrarmedico()
        {
            Console.Clear();
            Console.WriteLine("|| ---------------------------------\n|| CADASTRO DE MEDICO \n|| --------------------------------- ");
            int opcao;
            do
            {

                string nome, telefone, especialidade;
                int codigo;
                int opcaoE;
                StreamWriter x;
                especialidade = "";
                string CadastroMedico = "CadastroMedico.txt";

                //usando o metodo e abrindo o arquivo texto
                x = File.AppendText(CadastroMedico);

                Console.WriteLine("|| INSIRA SEU NOME: ");
                Console.Write("|| ");
                nome = Console.ReadLine().ToUpper();
                Console.WriteLine("|| INSIRA SEU TELEFONE: ");
                Console.Write("|| ");
                telefone = Console.ReadLine();
                Console.WriteLine("|| ESCOLHA A ESPECIALIDADE DO MÉDICO: ");

                do
                {
                    Console.WriteLine("|| 1 - CARDIOLOGIA");
                    Console.WriteLine("|| 2 - DERMATOLOGIA");
                    Console.WriteLine("|| 3 - CLINICA MÉDICA");
                    opcaoE = int.Parse(Console.ReadLine());
                    if (opcaoE == 1)
                    {
                        especialidade = "CARDIOLOGIA";
                    }
                    else if (opcaoE == 2)
                    {
                        especialidade = "DERMATOLOGIA";
                    }
                    else if (opcaoE == 3)
                    {
                        especialidade = "CLINICA MÉDICA";
                    }
                    else
                    {
                        Console.WriteLine("|| OPÇÃO INVÁLIDA");
                    }
                } while (opcaoE != 1 && opcaoE != 2 && opcaoE != 3);
                x.Close();
                codigo = GerarCodigoM2();
                x = File.AppendText(CadastroMedico);
                x.WriteLine(nome + "|" + telefone + "|" + especialidade + "|" + codigo);
                Console.WriteLine("Seu código é: " + codigo);
                x.Close();

                Console.Clear();
                Console.WriteLine("|| MÉDICO CADASTRADO COM SUCESSO!");
                Console.WriteLine("\n\n|| [1] CADASTRAR OUTRO MEDICO\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                Console.Write("||     ");
                opcao = int.Parse(Console.ReadLine());
                Console.Clear();
            } while (opcao != 0);
        }
        public static void cadastrarconsultaparte1()
        {

            Console.Clear();
            bool AchouPaciente;
            bool AchouMedico;
            bool PodeCadastro;
            PodeCadastro = false;

            int opcao = 10;
            do
            {

                StreamReader ler;
                StreamWriter x;
                StreamReader ler2;
                string arquivo;
                string arquivo2;
                arquivo = "CadastroPaciente.txt";
                arquivo2 = "CadastroMedico.txt";
                x = File.AppendText(arquivo);
                x.Close();
                x = File.AppendText(arquivo2);
                x.Close();
                ler = File.OpenText(arquivo);
                ler2 = File.OpenText(arquivo2);
                string nomeP;
                string nomeP2 = "";
                String[] informacao = new string[2] { "Nome: ", "Código: " };

                string codigoP = "";

                string[] busca2;
                string[] busca;
                busca = ler.ReadToEnd().Split('\n');
                busca2 = ler2.ReadToEnd().Split('\n');
                Console.WriteLine("|| ============================================");
                Console.WriteLine("|| DIGITE O NOME DO PACIENTE QUE DESEJA PESQUISAR: ");
                Console.Write("||     ");
                nomeP = Console.ReadLine().ToUpper();
                string[] resultado = new string[] { nomeP, "", "", codigoP };
                AchouPaciente = false;
                AchouMedico = false;

                for (int j = 0; j < busca.Length; j++)
                {
                    if (busca[j] != "")
                    {
                        resultado = busca[j].Split('|');
                        for (int i = 0; i < busca.Length; i++)
                        {
                            if (resultado[0] == nomeP)
                            {
                                AchouPaciente = true;
                                nomeP2 = resultado[0];
                                codigoP = resultado[4];
                            }
                        }
                    }
                }
                if (AchouPaciente == true)
                {
                    Console.WriteLine("|| ");
                    Console.WriteLine("|| " + informacao[0] + nomeP2);
                    Console.WriteLine("|| " + informacao[1] + codigoP);
                    Console.WriteLine("|| ");
                }
                else if (AchouPaciente == false)
                {
                    Console.Clear();
                    Console.WriteLine("|| O PACIENTE PESQUISADO NÃO ESTÁ CADASTRADO, TENTE NOVAMENTE!");
                    Console.WriteLine("\n\n|| [1] PESQUISAR NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                    Console.Write("||     ");
                    opcao = int.Parse(Console.ReadLine());
                }

                string codigoM = "";
                string nomeM1 = "";
                if (AchouPaciente == true)
                {
                    string nomeM2 = "";
                    string nomeM;
                    Console.WriteLine("|| ============================================");
                    Console.WriteLine("|| DIGITE O NOME DO MÉDICO QUE DESEJA PESQUISAR: ");
                    Console.Write("||     ");
                    nomeM = Console.ReadLine().ToUpper();

                    string[] resultado2 = new string[] { nomeM, "", "", codigoM };

                    for (int j = 0; j < busca2.Length; j++)
                    {

                        resultado2 = busca2[j].Split('|');
                        for (int i = 0; i < busca2.Length; i++)
                        {
                            if (resultado2[0] == nomeM)
                            {
                                AchouMedico = true;
                                nomeM2 = resultado2[0];
                                codigoM = resultado2[3];
                                nomeM1 = nomeM2;
                            }
                        }
                    }
                    if (AchouMedico == true)
                    {
                        Console.WriteLine("|| ");
                        Console.WriteLine("|| " + informacao[0] + nomeM2);
                        Console.WriteLine("|| " + informacao[1] + codigoM);
                        Console.WriteLine("|| ");
                    }
                    else if (AchouMedico == false)
                    {
                        Console.Clear();
                        Console.WriteLine("|| O MÉDICO PESQUISADO NÃO ESTÁ CADASTRADO, TENTE NOVAMENTE!");
                        Console.Write("||     ");
                        Console.WriteLine("\n\n|| [1] PESQUISAR NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                        Console.Write("||     ");
                        opcao = int.Parse(Console.ReadLine());
                    }
                    if (AchouMedico == true && AchouPaciente == true)
                    {
                        PodeCadastro = true;
                        opcao = 0;
                    }
                }
                ler.Close();
                ler2.Close();
                cadastrarconsultaparte2(codigoM, codigoP, nomeM1, nomeP2, PodeCadastro);
            } while (opcao != 0);
        }
        public static void cadastrarconsultaparte2(string CodigoM, string CodigoP, string NomeM1, string NomeP2, bool PodeCadastro)
        {
            if (PodeCadastro == true)
            {
                int opcao2 = 10;
                do
                {
                    string data;
                    int CodigoC;
                    string arquivo;
                    string hora;
                    string texto;
                    int numConsulMed;
                    bool Horario;
                    String[] resultado = new string[4];
                    String[] linhas;
                    StreamWriter x;

                    Horario = false;

                    Console.WriteLine("|| CADASTRAR CONSULTA");
                    Console.WriteLine("|| INSIRA A DATA DESEJADA: EX: (25/05/2019)");
                    Console.Write("|| ");
                    data = Console.ReadLine();

                    numConsulMed = 0;

                    Console.WriteLine("||                 HORÁRIOS: ");
                    Console.WriteLine("|| ");
                    Console.WriteLine("|| 8:00   8:30   9:00   9:30   10:00  10:30");
                    Console.WriteLine("|| 11:00  11:30  12:00  12:30  13:00  13:30");
                    Console.WriteLine("|| 14:00  14:30  15:00  15:30  16:00  16:30");
                    Console.WriteLine("|| 17:00  17:30  18:00  18:30  19:00  19:30");
                    Console.WriteLine("|| INSIRA ALGUM HORÁRIO, NO MESMO FORMATO.");
                    Console.Write("|| ");
                    hora = Console.ReadLine();
                    if (hora == "8:00" || hora == "8:30" || hora == "9:00" || hora == "9:30" || hora == "10:00" || hora == "10:30" ||
                        hora == "11:00" || hora == "11:30" || hora == "12:00" || hora == "12:30" || hora == "13:00" || hora == "13:30" ||
                        hora == "14:00" || hora == "14:30" || hora == "15:00" || hora == "15:30" || hora == "16:00" || hora == "16:30" ||
                        hora == "17:00" || hora == "17:30" || hora == "18:00" || hora == "18:30" || hora == "19:00" || hora == "19:30")
                    {
                        arquivo = ("Consultas.txt");
                        x = File.AppendText(arquivo);
                        x.Close();
                        StreamReader ler;
                        ler = File.OpenText(arquivo);
                        CodigoC = GerarCodigoC();
                        string Codigo;
                        texto = ler.ReadToEnd();
                        ler.Close();
                        if (texto == "")
                        {
                            Console.Clear();
                            Console.WriteLine("|| SUA CONSULTA FOI MARCADA!");
                            Console.WriteLine("|| CÓDIGO DA CONSULTA: " + CodigoC);
                            x = File.AppendText(arquivo);
                            x.WriteLine(data + "|" + hora + "|" + CodigoC + "|" + NomeM1 + "|" + CodigoM + "|" + NomeP2 + "|" + CodigoP);
                            x.Close();
                            Console.WriteLine("\n\n|| [1] CADASTRAR CONSULTA NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                            Console.Write("||     ");
                            opcao2 = int.Parse(Console.ReadLine());
                        }
                        else
                        {
                            linhas = texto.Split('\n');
                            for (int i = 0; i < linhas.Length; i++)
                            {
                                if (linhas[i] != "")
                                {
                                    resultado = linhas[i].Split('|');
                                    Codigo = resultado[3];
                                    if (resultado[1] == hora && data == resultado[0])
                                    {
                                        Horario = false;
                                    }
                                    else if (resultado[1] != hora && data == resultado[0])
                                    {
                                        if (Codigo == resultado[3])
                                        {
                                            numConsulMed++;
                                            if (numConsulMed < 2)
                                            {
                                                Horario = true;
                                            }
                                            else
                                            {
                                                Horario = false;
                                            }
                                        }
                                        else
                                        {
                                            Horario = true;
                                        }
                                    }
                                    else if (resultado[1] != hora && data != resultado[0])
                                    {
                                        Horario = true;
                                    }
                                }
                            }
                            if (Horario == false)
                            {
                                Console.Clear();
                                Console.WriteLine("|| ESSE HORÁRIO NÃO ESTÁ DISPONÍVEL");
                                Console.WriteLine("\n\n|| [1] CADASTRAR CONSULTA NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                                Console.Write("||     ");
                                opcao2 = int.Parse(Console.ReadLine());
                            }
                            else
                            {
                                Console.Clear();
                                Console.WriteLine("|| SUA CONSULTA FOI MARCADA!");
                                Console.WriteLine("|| O CÓDIGO DA CONSULTA É: " + CodigoC);
                                x = File.AppendText(arquivo);
                                x.WriteLine(data + "|" + hora + "|" + CodigoC + "|" + NomeM1 + "|" + CodigoM + "|" + NomeP2 + "|" + CodigoP);
                                x.Close();
                                Console.WriteLine("\n\n|| [1] CADASTRAR CONSULTA NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                                Console.Write("||     ");
                                opcao2 = int.Parse(Console.ReadLine());
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("|| HORÁRIO INVÁLIDO");
                        Console.WriteLine("\n\n|| [1] CADASTRAR CONSULTA NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                        Console.Write("||     ");
                        opcao2 = int.Parse(Console.ReadLine());
                    }
                    if (opcao2 != 1 && opcao2 != 0)
                    {
                        do
                        {
                            Console.WriteLine("|| OPÇÃO INVÁLIDA");
                            Console.WriteLine("\n\n|| [1] CADASTRAR CONSULTA NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                            Console.Write("||     ");
                            opcao2 = int.Parse(Console.ReadLine());

                        } while (opcao2 != 1 || opcao2 != 0);
                    }
                } while (opcao2 != 0);
            }

        }

        // CANCELAR CONSULTA
        public static void cancelaconsulta1()
        {
            Console.Clear();
            Console.WriteLine("|| ---------------------------------\n|| CANCELA CONSULTA \n|| --------------------------------- ");

            {

                Console.Clear();
                bool AchouPaciente;
                bool AchouMedico;
                bool cancelaconsulta;
                cancelaconsulta = false;

                int opcao = 10;
                do
                {

                    StreamReader ler;
                    StreamWriter x;
                    StreamReader ler2;
                    string arquivo;
                    string arquivo2;
                    arquivo = "CadastroPaciente.txt";
                    arquivo2 = "CadastroMedico.txt";
                    x = File.AppendText(arquivo);
                    x.Close();
                    x = File.AppendText(arquivo2);
                    x.Close();
                    ler = File.OpenText(arquivo);
                    ler2 = File.OpenText(arquivo2);
                    string nomeP;
                    string nomeP2 = "";
                    String[] informacao = new string[2] { "Nome: ", "Código: " };

                    string codigoP = "";

                    string[] busca2;
                    string[] busca;
                    busca = ler.ReadToEnd().Split('\n');
                    busca2 = ler2.ReadToEnd().Split('\n');
                    Console.WriteLine("|| ============================================");
                    Console.WriteLine("|| DIGITE O NOME DO PACIENTE QUE DESEJA CANCELAR A CONSULTA: ");
                    Console.Write("||     ");
                    nomeP = Console.ReadLine().ToUpper();
                    string[] resultado = new string[] { nomeP, "", "", codigoP };
                    AchouPaciente = false;
                    AchouMedico = false;

                    for (int j = 0; j < busca.Length; j++)
                    {
                        if (busca[j] != "")
                        {
                            resultado = busca[j].Split('|');
                            for (int i = 0; i < busca.Length; i++)
                            {
                                if (resultado[0] == nomeP)
                                {
                                    AchouPaciente = true;
                                    nomeP2 = resultado[0];
                                    codigoP = resultado[4];
                                }
                            }
                        }
                    }
                    if (AchouPaciente == true)
                    {
                        Console.WriteLine("|| ");
                        Console.WriteLine("|| " + informacao[0] + nomeP2);
                        Console.WriteLine("|| " + informacao[1] + codigoP);
                        Console.WriteLine("|| ");
                    }
                    else if (AchouPaciente == false)
                    {
                        Console.Clear();
                        Console.WriteLine("|| O PACIENTE PESQUISADO NÃO ESTÁ CADASTRADO, TENTE NOVAMENTE!");
                        Console.WriteLine("\n\n|| [1] PESQUISAR NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                        Console.Write("||     ");
                        opcao = int.Parse(Console.ReadLine());
                    }

                    string codigoM = "";
                    string nomeM1 = "";
                    if (AchouPaciente == true)
                    {
                        string nomeM2 = "";
                        string nomeM;
                        Console.WriteLine("|| ============================================");
                        Console.WriteLine("|| DIGITE O NOME DO MÉDICO DA CONSULTA A SER CANCELADA: ");
                        Console.Write("||     ");
                        nomeM = Console.ReadLine().ToUpper();

                        string[] resultado2 = new string[] { nomeM, "", "", codigoM };

                        for (int j = 0; j < busca2.Length; j++)
                        {

                            resultado2 = busca2[j].Split('|');
                            for (int i = 0; i < busca2.Length; i++)
                            {
                                if (resultado2[0] == nomeM)
                                {
                                    AchouMedico = true;
                                    nomeM2 = resultado2[0];
                                    codigoM = resultado2[3];
                                    nomeM1 = nomeM2;
                                }
                            }
                        }
                        if (AchouMedico == true)
                        {
                            Console.WriteLine("|| ");
                            Console.WriteLine("|| " + informacao[0] + nomeM2);
                            Console.WriteLine("|| " + informacao[1] + codigoM);
                            Console.WriteLine("|| ");
                        }
                        else if (AchouMedico == false)
                        {
                            Console.Clear();
                            Console.WriteLine("|| O MÉDICO PESQUISADO NÃO ESTÁ CADASTRADO, TENTE NOVAMENTE!");
                            Console.Write("||     ");
                            Console.WriteLine("\n\n|| [1] PESQUISAR NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                            Console.Write("||     ");
                            opcao = int.Parse(Console.ReadLine());
                        }
                        if (AchouMedico == true && AchouPaciente == true)
                        {
                            cancelaconsulta = true;
                            opcao = 0;
                        }
                    }
                    ler.Close();
                    ler2.Close();
                    cancelaconsulta2(codigoM, codigoP, nomeM1, nomeP2, cancelaconsulta);
                } while (opcao != 0);
            }
        }
        public static void cancelaconsulta2(string CodigoM, string CodigoP, string NomeM1, string NomeP2, bool Podecancelamento)
        {
            if (Podecancelamento == true)
            {
                int opcao2 = 10;
                do
                {
                    string data;
                    string arquivo;
                    string hora;
                    string texto;
                    int numConsulMed;
                    bool Horario;
                    String[] resultado = new string[4];
                    String[] linhas;
                    StreamWriter x;

                    Horario = false;

                    Console.WriteLine("|| CANCELAR CONSULTA");
                    Console.WriteLine("|| INSIRA A DATA DA CONSULTA A SER CANCELADA: EX: (24/04/2024)");
                    Console.Write("|| ");
                    data = Console.ReadLine();

                    numConsulMed = 0;

                    ;
                    Console.WriteLine("|| INSIRA O HORARIO DA CONSULTA QUE DESEJA CANCELAR(EX:8:30).");
                    Console.Write("|| ");
                    hora = Console.ReadLine();
                    if (hora == "8:00" || hora == "8:30" || hora == "9:00" || hora == "9:30" || hora == "10:00" || hora == "10:30" ||
                        hora == "11:00" || hora == "11:30" || hora == "12:00" || hora == "12:30" || hora == "13:00" || hora == "13:30" ||
                        hora == "14:00" || hora == "14:30" || hora == "15:00" || hora == "15:30" || hora == "16:00" || hora == "16:30" ||
                        hora == "17:00" || hora == "17:30" || hora == "18:00" || hora == "18:30" || hora == "19:00" || hora == "19:30")
                    {
                        arquivo = "Consultas.txt";
                        StreamReader ler;
                        ler = File.OpenText(arquivo);
                        texto = ler.ReadToEnd();
                        ler.Close();
                            linhas = texto.Split('\n');
                        for (int i = 0; i < linhas.Length; i++)
                        {
                            if (linhas[i] != "")
                            {
                                resultado = linhas[i].Split('|');
                                if (resultado[1] == hora && data == resultado[0])
                                {
                                    Horario = true;
                                }
                                
                            }
                        }
                        if (Horario == false)
                        {
                            Console.Clear();
                            Console.WriteLine("|| ESSA CONSULTA NÃO EXISTE.");
                            Console.WriteLine("\n\n|| [1] CANCELAR CONSULTA NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                            Console.Write("||     ");
                            opcao2 = int.Parse(Console.ReadLine());
                        }
                        else
                        {
                            string consulta = null;
                            ler = File.OpenText(arquivo);
                            texto = ler.ReadToEnd();
                            linhas = texto.Split('\n');
                            for (int i = 0; i < linhas.Length; i++)
                            {
                                if (linhas[i] != "")
                                {
                                    resultado = linhas[i].Split('|');
                                    if (resultado[1] == hora && data == resultado[0])
                                    {
                                        consulta = linhas[i];
                                    }
                                }
                            }
                            ler.Close();
                                using (StreamWriter escrever1 = new StreamWriter("Consultas.txt"))
                                {
                                    for (int i = 0; i < linhas.Length; i++)
                                    {


                                        if (String.Compare(linhas[i], consulta) == 0)
                                        {
                                            continue;
                                        }
                                        escrever1.WriteLine(linhas[i]);

                                        escrever1.Close();
                                    }
                                }
                            }
                        

                            Console.Clear();
                            Console.WriteLine("|| ");
                            Console.WriteLine("|| CONSULTA CANCELADA!");
                            Console.WriteLine("|| ");
                            Console.WriteLine("\n\n|| [1] CANCELAR OUTRA CONSULTA\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                            Console.Write("||     ");
                            opcao2 = int.Parse(Console.ReadLine());
                        }                        
                    
                    else
                    {
                        Console.WriteLine("|| HORÁRIO INVÁLIDO");
                        Console.WriteLine("\n\n|| [1] CANCELAR CONSULTA NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                        Console.Write("||     ");
                        opcao2 = int.Parse(Console.ReadLine());
                    }
                    if (opcao2 != 1 && opcao2 != 0)
                    {
                        do
                        {
                            Console.WriteLine("|| OPÇÃO INVÁLIDA");
                            Console.WriteLine("\n\n|| [1] CANCELAR CONSULTA NOVAMENTE\n|| [0] VOLTAR AO MENU ANTERIOR\n|| -----------------------------\n|| DIGITE A OPÇÃO DESEJADA: ");
                            Console.Write("||     ");
                            opcao2 = int.Parse(Console.ReadLine());

                        } while (opcao2 != 1 || opcao2 != 0);
                    }
                } while (opcao2 != 0);
            }

        }


        // PESQUISAR POR MEDICO
        public static void pesquisamedico()
        {
            int opcao = 10;
            do
            {


                Console.Clear();
                Console.WriteLine("|| ---------------------------------\n|| PESQUISA POR MÉDICO \n|| --------------------------------- ");
                string arquivo, medico;
                String[] resul = new string[1] { "" };
                string[] vet = new string[6];
                bool Achou_Medico = false;
                string texto;
                String[] busca;
                arquivo = "Consultas.txt";
                StreamReader ler;
                if (File.Exists(arquivo) == true)
                {
                    Console.Clear();
                    Console.WriteLine("|| ----------------------------------------------");
                    Console.WriteLine("|| DIGITE O NOME DO MÉDICO QUE DESEJA PESQUISAR: ");
                    Console.Write("||       ");
                    medico = Console.ReadLine().ToUpper();
                    ler = File.OpenText(arquivo);
                    texto = ler.ReadToEnd();
                    busca = texto.Split('\n');
                    for (int i = 0; i < busca.Length; i++)
                    {
                        if (busca[i] != "")
                        {
                            vet = busca[i].Split('|');
                            if (vet[3] == medico)
                            {
                                Achou_Medico = true;
                            }
                        }
                    }
                    string[] result2;
                    string[] busca2 = new string[7];
                    if (Achou_Medico == true)
                    {

                        Console.WriteLine("|| ----------------------------\n||CONSULTAS DO MEDICO PESQUISADO\n|| ----------------------------");
                        result2 = texto.Split('\n');
                        for (int i = 0; i < result2.Length; i++)
                        {
                            if (result2[i] != "")
                            {
                                busca2 = result2[i].Split('|');
                                {
                                    if (busca2[3] == medico)
                                    {
                                        Console.WriteLine("|| MÉDICO: " + busca2[3] + " PACIENTE: " + busca2[5]);
                                        Console.WriteLine("|| DATA: " + busca2[0] + " HORÁRIO: " + busca2[1]);
                                        Console.WriteLine("|| ");
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("|| NÃO FORAM ENCONTRADO CONSULTAS COM  O MEDICO PESQUISADO .!");
                    }
                    ler.Close();
                    Console.WriteLine("||\n||\n|| [1] PESQUISAR POR OUTRO MEDICO \n|| [0] VOLTAR AO MENU ANTERIOR\n||----------------------------\n||  DIGITE A OPÇÃO DESEJADA: ");
                    Console.Write("||       ");
                    opcao = int.Parse(Console.ReadLine());
                }
            } while (opcao != 0);
        }

        // PESQUISA POR ESPECIALIDADES

        public static void pesquisaespecialidades()
        {
            {
                int opcao = 10;
                do
                {
                    Console.Clear();
                    string arquivo, especialidade;
                    String[] resul;
                    string[] vet = new string[7];
                    bool AchouMed = false;
                    string texto;
                    String[] busca;
                    arquivo = @"CadastroMedico.txt";
                    StreamReader ler;
                    if (File.Exists(arquivo) == true)
                    {
                        Console.Clear();
                        Console.WriteLine("|| ----------------------------------------------");
                        Console.WriteLine("|| DIGITE O NOME DA ESPECIALIDADE  QUE DESEJA PESQUISAR: ");
                        Console.Write("||       ");
                        especialidade = Console.ReadLine().ToUpper();
                        ler = File.OpenText(arquivo);
                        texto = ler.ReadToEnd();
                        busca = texto.Split('\n');
                        for (int i = 0; i < busca.Length; i++)
                        {
                            if (busca[i] != "")
                            {
                                vet = busca[i].Split('|');
                                if (vet[2] == especialidade)
                                {
                                    AchouMed = true;
                                }
                            }

                        }
                        string[] result2;
                        string[] busca3 = new string[3];
                        if (AchouMed == true)
                        {
                            Console.WriteLine("|| ----------------------------\n|| MEDICOS NA ESPECIALIDADES PESQUISADA\n|| ----------------------------");
                            result2 = texto.Split('\n');
                            for (int i = 0; i < result2.Length; i++)
                            {
                                if (result2[i] != "")
                                {
                                    busca3 = result2[i].Split('|');
                                    if (busca3[2] == especialidade)
                                    {
                                        Console.WriteLine("|| NOME: " + busca3[0] + " ESPECIALIDADE: " + busca3[2]);
                                        Console.WriteLine("|| TELEFONE: " + busca3[1] + " CÓDIGO DO MÉDICO: " + busca3[3]);
                                        Console.WriteLine("||");
                                    }
                                }
                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("|| NÃO FORAM ENCONTRADOS MÉDICOS OU ESPECIALIADES.!");
                        }
                        ler.Close();

                    }
                    Console.WriteLine("||\n||\n|| [1] PESQUISAR OUTRO ESPECIALIDADE \n|| [0] VOLTAR AO MENU ANTERIOR\n||----------------------------\n||  DIGITE A OPÇÃO DESEJADA: ");
                    Console.Write("||       ");
                    opcao = int.Parse(Console.ReadLine());
                } while (opcao != 0);
            }
        }

        // PESQUISA POR PACIENTES
        public static void pesquisapaciente()
        {
            int opcao = 10;
            do
            {
                Console.Clear();
                Console.WriteLine("|| ---------------------------------\n|| RELATÓRIO DE CONSULTAS DE PACIENTE \n|| --------------------------------- ");
                string arquivo;
                string texto;
                string nome;
                bool achouC = false;
                bool achouP = false;
                string[] busca;
                string[] result1;
                DateTime datas;
                arquivo = "Consultas.txt";
                DateTime dataNow;
                dataNow = DateTime.Today;
                Console.WriteLine("|| INSIRA O NOME DO PACIENTE, PARA RECEBER O RELATÓRIO DE CONSULTAS.");
                Console.Write("|| ");
                nome = Console.ReadLine().ToUpper();

                if (File.Exists(arquivo))
                {
                    StreamReader ler = new StreamReader(arquivo);
                    ler = File.OpenText(arquivo);
                    texto = ler.ReadToEnd();
                    busca = texto.Split('\n');
                    for (int i = 0; i < busca.Length; i++)
                    {
                        if (busca[i] != "")
                        {
                            result1 = busca[i].Split('|');
                            datas = Convert.ToDateTime(result1[0]);
                            if (nome == result1[5])
                            {
                                achouP = true;
                                if (datas < dataNow)
                                {
                                    achouC = true;
                                }
                            }
                        }
                    }
                    if (achouP == false)
                    {
                        Console.WriteLine("|| PACIENTE NÃO ENCONTRADO.");
                    }
                    if (achouC == true)
                    {
                        Console.WriteLine("|| ---------------------------------\n|| CONSULTAS DO PACIENTE ATÉ A DATA ATUAL \n|| --------------------------------- ");
                        for (int i = 0; i < busca.Length; i++)
                        {
                            if (busca[i] != "")
                            {
                                result1 = busca[i].Split('|');
                                datas = Convert.ToDateTime(result1[0]);
                                if (datas < dataNow)
                                {
                                    Console.WriteLine("|| ");
                                    Console.WriteLine("|| DATA: " + result1[0] + " HORA: " + result1[1]);
                                    Console.WriteLine("|| MÉDICO: " + result1[3] + " PACIENTE: " + result1[5]);
                                    Console.WriteLine("|| CÓDIGO DA CONSULTA: " + result1[2]);
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("|| NÃO FORAM ENCONTRADAS CONSULTAS DO PACIENTE ATÉ O DIA DE HOJE.");
                    }

                }
                Console.WriteLine("||\n||\n|| [0] VOLTAR AO MENU ANTERIOR\n||----------------------------\n||  DIGITE A OPÇÃO DESEJADA: ");
                Console.Write("||       ");
                opcao = int.Parse(Console.ReadLine());




            } while (opcao != 0);
        }



        // PESQUISA POR DATA
        public static void pesquisadata()
        {
            int opcao = 10;
            do
            {
                Console.Clear();
                Console.WriteLine("|| ---------------------------------\n|| PESQUISA POR DATA \n|| --------------------------------- ");
                string arquivo, data;
                String[] resul = new string[1] { "" };
                string[] vet = new string[6];
                bool AchouData = false;
                string texto;
                String[] busca;

                arquivo = "Consultas.txt";
                StreamReader ler;
                if (File.Exists(arquivo) == true)
                {
                    Console.Clear();
                    Console.WriteLine("|| ----------------------------------------------");
                    Console.WriteLine("|| DIGITE A DATA QUE DESEJA PESQUISAR: ");
                    Console.Write("||       ");
                    data = Console.ReadLine().ToUpper();
                    ler = File.OpenText(arquivo);
                    texto = ler.ReadToEnd();
                    busca = texto.Split('\n');
                    for (int i = 0; i < busca.Length; i++)
                    {
                        if (busca[i] != "")
                        {
                            vet = busca[i].Split('|');
                            if (vet[0] == data)
                            {
                                AchouData = true;
                            }
                        }
                    }
                    string[] result2;
                    string[] busca2 = new string[7];
                    if (AchouData == true)
                    {

                        Console.WriteLine("|| ----------------------------\n||CONSULTAS NA DATA PESQUISADA\n|| ----------------------------");
                        result2 = texto.Split('\n');
                        for (int i = 0; i < result2.Length; i++)
                        {
                            if (result2[i] != "")
                            {
                                busca2 = result2[i].Split('|');
                                {
                                    if (busca2[0] == data)
                                    {
                                        Console.WriteLine("|| MÉDICO: " + busca2[3] + " PACIENTE: " + busca2[5]);
                                        Console.WriteLine("|| CÓDIGO: " + busca2[2] + " HORÁRIO: " + busca2[1]);
                                        Console.WriteLine("|| ");
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("|| NÃO FORAM ENCONTRADOS CONSULTAS NO DIA PESQUISADO.!");
                    }
                    ler.Close();
                    Console.WriteLine("||\n||\n|| [1] PESQUISAR POR OUTRA DATA \n|| [0] VOLTAR AO MENU ANTERIOR\n||----------------------------\n||  DIGITE A OPÇÃO DESEJADA: ");
                    Console.Write("||       ");
                    opcao = int.Parse(Console.ReadLine());
                }
            } while (opcao != 0);
        }


        // PROGRAMA PRINCIPAL

        static void Main(string[] args)
        {
            int opcao = 10, opcao2 = 10;


            do
            {
                Console.Clear();
                DateTime dataEntrada = DateTime.Now;


                Console.WriteLine("|| ---------------------------------");
                Console.WriteLine("|| CLINICA VIVA BEM ");
                Console.WriteLine("|| ");
                Console.WriteLine("|| " + dataEntrada);
                Console.WriteLine("|| ");
                Console.WriteLine("|| ---------------------------------");
                Console.WriteLine("|| MENU DE OPÇÕES                ");
                Console.WriteLine("||                               " +
                    "              \n|| [1] CADASTRAR PACIENTE             " +
                    "              \n|| [2] CADASTRAR MEDICO        " +
                    "              \n|| [3] CADASTRAR CONSULTA           " +
                    "              \n|| [4] CANCELAR CONSULTA   " +
                    "              \n|| [5] PESQUISA DE CONSULTAS          " +
                    "              \n|| [6] CONSULTAS POR MEDICO                  " +
                    "              \n|| [7] FUNÇÃO EXTRA (PESQUISA POR ESPECIALIDADES) " +
                    "              \n|| [0] FECHAR O PROGRAMA " +
                    "              \n|| --------------------------------- \n" +
                    "|| DIGITE A OPÇÃO DESEJADA:      ");
                Console.Write("||    ");
                opcao = int.Parse(Console.ReadLine());
                if (opcao == 1)
                    cadastrarpaciente();
                else if (opcao == 2)
                    cadastrarmedico();
                else if (opcao == 3)
                    cadastrarconsultaparte1();
                else if (opcao == 4)
                    cancelaconsulta1();
                else if (opcao == 6)
                    pesquisamedico();

                else if (opcao == 7)
                    pesquisaespecialidades();

                else if (opcao == 5)
                    do
                    {
                        Console.Clear();
                        Console.WriteLine("|| ---------------------");
                        Console.WriteLine("|| MENU DE PESQUISAS DE DATAS, CONSULTA DO DIA");
                        Console.WriteLine("|| ---------------------");
                        Console.WriteLine("||\n|| [1] PESQUISAR POR DATA  \n|| [2] PESQUISAR POR NOME DO PACIENTE \n|| [0] VOLTAR AO MENU ANTERIOR  \n|| ---------------------  \n|| DIGITE A OPÇAO DESEJADA:  ");
                        Console.Write("||       ");
                        opcao2 = int.Parse(Console.ReadLine());
                        if (opcao2 == 1)
                            pesquisadata();
                        else if (opcao2 == 2)
                            pesquisapaciente();


                    } while (opcao2 != 0);

            } while (opcao != 0);

        }
    }

}